
https://anteelo.com/

https://www.creativebloq.com/web-design/parallax-scrolling-1131762

https://www.creativebloq.com/how-to/8-state-of-the-art-css-features

https://codepen.io/RadicalCaitlin/pen/yORGoa

https://web-design-weekly.com/2015/07/21/creating-better-css/

https://cssguidelin.es/

space-between:

file:///C:/Users/mastermilmar/Documents/Kraft%20sajt/web_dev-master/index.htm

https://anteelo.com/

https://stackoverflow.com/questions/4804581/css-expand-float-child-div-height-to-parents-height

https://css-tricks.com/almanac/properties/h/height/

https://www.w3schools.com/cssref/pr_gen_content.asp

https://scripteden.com/download-best-13-mobile-friendly-and-responsive-menus-jquery-plugins-of-2018/

https://navnav.co/

https://github.com/mblode/burger

https://www.w3schools.com/howto/howto_css_navbar_icon.asp

https://www.w3schools.com/css/css_navbar.asp

https://www.w3schools.com/howto/howto_js_topnav_responsive.asp

https://medium.com/level-up-web/20-responsive-navigation-solutions-examples-codes-21644390afeb

https://css-tricks.com/responsive-menu-concepts/

https://developer.mozilla.org/en-US/docs/Web/CSS/::after

https://www.w3schools.com/csSref/sel_hover.asp

https://www.w3schools.com/csSref/sel_link.asp

https://sebas.design/

https://www.creativebloq.com/web-design/parallax-scrolling-1131762

http://flexbox.malven.co/

http://grid.malven.co/

https://www.creativebloq.com/advice/the-web-designer-s-guide-to-flexbox

https://www.w3schools.com/howto/howto_css_parallax.asp

https://www.w3schools.com/cssref/pr_background-image.asp

https://developer.mozilla.org/en-US/docs/Web/CSS/background-image

https://stackoverflow.com/questions/29036231/how-can-i-have-a-position-fixed-behaviour-for-a-flexbox-sized-element

https://css-tricks.com/fun-viewport-units/

https://web-design-weekly.com/2014/11/18/viewport-units-vw-vh-vmin-vmax/

https://web-design-weekly.com/2015/07/21/creating-better-css/

http://oocss.org/grids_docs.html

